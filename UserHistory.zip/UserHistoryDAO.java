package project.dao;

import project.dto.UserHistoryDTO;

public interface UserHistoryDAO {

	public int addDietMenu(UserHistoryDTO userhistory);
}
