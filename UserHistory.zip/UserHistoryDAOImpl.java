package project.dao;

import static project.fw.DBUtil.*;
import  java.sql.Connection;
import  java.sql.PreparedStatement;
import java.sql.SQLException;
import static project.fw.Query.*;
import project.dto.UserHistoryDTO;

public class UserHistoryDAOImpl implements UserHistoryDAO {

	@Override
	public int addDietMenu(UserHistoryDTO userhistory) {
		Connection con = null;
		PreparedStatement stmt = null;
		int result = 0;
		try {
			con = getConnect();
			stmt = con.prepareStatement(USERHISTORY_INSERT);
			 
			stmt.setString(1, userhistory.getMem_id());
			stmt.setString(2, userhistory.getDietBreakfast());      
			stmt.setString(3, userhistory.getDietDinner());      
			stmt.setString(4, userhistory.getKcal());      
			
			result = stmt.executeUpdate();
			System.out.println(result + "�� �� ���� ����!!");
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}

		return result;
	}

}
