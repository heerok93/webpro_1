package project.fw;

//SQL�� �����ϴ� Ŭ���� - �����ӿ�ũ ������� �ϴ� ��� XML���·� ����
public class Query { // sql ���ɹ��� �����ش�.
	public static String MEMBERLIST_INSERT = // ������ ȸ������ sql
	"insert into membertable values(?,?,?,?,?,?,sysdate)";

	public static String EXERCISE_INSERT = // ������ ��Է� sql
	"insert into exercisetable values(?,?,?,?,?)";

	public static String DIET_INSERT = // ������ �޴��Է� sql
	"insert into diettable values(?,?,?,?)";

	public static String USERHISTORY_INSERT = // ����� �޴� �μ�Ʈ ����
	"insert into userhistory values(to_char(sysdate, 'yyyymmddhh24miss'), ?, ?, ?, ?)";

	public static String IDPASS_SELECT = "select * from membertable where mem_id = ? and mem_passwd = ?";

	public static String NAMETELEMAIL_SELECT = "select * from membertable where mem_name = ? and mem_tel = ? and mem_email = ?";
	public static String NAMEIDTELEMAIL_SELECT = "select * from membertable where mem_name = ? and mem_id = ? and mem_tel = ? and mem_email = ?";
	public static String PASSCHANGE_UPDATE = "update membertable set mem_passwd = ? where mem_id = ?";

	public static String INSERTINBODY_INSERT = "insert into inbodyinfotable values(sysdate, ?,?,?,?,?,?)";
	public static String INSERTINBODY_SELECT = "select * from inbodyinfotable inbdy, membertable mt where mt.mem_id = ? and mt.mem_id = inbdy.mem_id";
	public static String MEMBER_LISTPRINT = "select mem_id , mem_name , mem_passwd , mem_gender , mem_tel , mem_email , mem_signupdate "
			+ "from membertable " + "where mem_id = ?";

	public static String INSERTDIETLIST_INSERT = "insert into dietlisttable values(?,?)";
	public static String INSERTDIET_INSERT = "insert into diettable values(?,?,?,?,?)";

	public static String RECOMMEND_DIETLIST = "select * from dietlisttable where dietlist_id = ?";
	public static String RECOMMEND_DIETINFO = "select * from diettable dt, dietlisttable dlt "
			+ "where dt.diet_";

	public static String GETDATELIST_GOALPAGE = "select deptname from diettable";

	public static String GOAL_INSERT = "insert into membergoaltable values(?,?,?,?)";

	public static String GOAL_SELECT = // ��ǥ�Է� ���
	"select mem_id, memgol_finaldate, memgol_weight, memgol_muscle from membergoaltable where mem_id=?";
	// * mem_id, memgol_finaldate, memgol_weight, memgol_muscle

	public static String SELECT_DIETLISTID = "select dietlist_id from dietlisttable";

	public static String INSERTEXERCISE_SELECT = "select ex_name,ex_kcal,ex_videolink from Exercisetable";
}
