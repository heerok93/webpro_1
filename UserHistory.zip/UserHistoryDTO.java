package project.dto;

public class UserHistoryDTO {
	public String historydate;
	public String mem_id;
	public String dietBreakfast;
	public String dietDinner;
	public String kcal;
	
	public UserHistoryDTO(String historydate, String mem_id,
			String dietBreakfast, String dietDinner, String kcal) {
		this.historydate = historydate;
		this.mem_id = mem_id;
		this.dietBreakfast = dietBreakfast;
		this.dietDinner = dietDinner;
		this.kcal = kcal;
	}

	public String getHistorydate() {
		return historydate;
	}

	public void setHistorydate(String historydate) {
		this.historydate = historydate;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getDietBreakfast() {
		return dietBreakfast;
	}

	public void setDietBreakfast(String dietBreakfast) {
		this.dietBreakfast = dietBreakfast;
	}

	public String getDietDinner() {
		return dietDinner;
	}

	public void setDietDinner(String dietDinner) {
		this.dietDinner = dietDinner;
	}

	public String getKcal() {
		return kcal;
	}

	public void setKcal(String kcal) {
		this.kcal = kcal;
	}

	@Override
	public String toString() {
		return "UserHistoryDTO [historydate=" + historydate + ", mem_id="
				+ mem_id + ", dietBreakfast=" + dietBreakfast + ", dietDinner="
				+ dietDinner + ", kcal=" + kcal + "]";
	}
}
